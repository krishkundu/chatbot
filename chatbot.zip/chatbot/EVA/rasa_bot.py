'''
Created on May 15, 2018

@author: krishna kundu
'''
from eva_core import Eva
if __name__ == '__main__':
    eva = Eva()
    sender_id=1
    while True:
        ip = input("Enter Bot Text:: User"+str(sender_id)+":")
        if(ip.__eq__("sender")):
            sender_id+=1
            continue 
        else:
            resp = eva.handle_request(ip, sender_id=sender_id)
            i_res = eva.nlu_interpreter.parse(ip);
            print("\n",i_res,"\n End")
            print(resp)
    pass