## Generated Story -6872664423934330085
* intent_affirm
    - utter_on_it
    - action_on_user
    - slot{"username": null}
    - slot{"actiontype": null}
* intent_thanks
    - utter_thanks
* intent_bye
    - utter_goodbye
    - export
## Generated Story -218229452344574352
    - utter_on_it
    - utter_ask_confirm
* intent_affirm
    - utter_on_it
    - action_on_user
    - slot{"username": null}
    - slot{"actiontype": null}
* intent_bye
    - utter_goodbye
    - export
## Generated Story -1027184104398475265
    - action_on_user
    - slot{"username": null}
    - slot{"actiontype": null}
* intent_thanks
    - utter_thanks
* intent_bye
    - utter_goodbye
    - export
## Generated Story 6658563215429589534
* intent_affirm
    - utter_on_it
    - action_on_user
    - slot{"username": null}
    - slot{"actiontype": null}
* intent_bye
    - utter_goodbye
    - export
## Generated Story -6872664423934330085
* intent_affirm
    - utter_on_it
    - action_on_user
    - slot{"username": null}
    - slot{"actiontype": null}
* intent_thanks
    - utter_thanks
* intent_bye
    - utter_goodbye
    - export
## Generated Story -218229452344574352
    - utter_on_it
    - utter_ask_confirm
* intent_affirm
    - utter_on_it
    - action_on_user
    - slot{"username": null}
    - slot{"actiontype": null}
* intent_bye
    - utter_goodbye
    - export
## Generated Story 2431651027018764496
    - slot{"actiontype": null}
* intent_bye
    - utter_goodbye
    - export
* intent_user_issue
    - utter_ask_more_info
## Generated Story 7983009597387628637
* intent_bye
    - utter_goodbye
    - export
* intent_user_issue{"username": "65889922"}
    - slot{"username": "65889922"}
    - slot{"username": "65889922"}
    - utter_ask_actiontype
## Generated Story 4451189349242159392
    - slot{"actiontype": null}
* intent_bye
    - utter_goodbye
    - export
* intent_bye
    - utter_goodbye
## Generated Story 2881553204458247855
* intent_bye
    - utter_goodbye
    - export
* intent_user_issue{"username": "647229"}
    - slot{"username": "647229"}
    - slot{"username": "647229"}
    - utter_ask_actiontype
## Generated Story -4390926169037032749
    - utter_thanks
* intent_bye
    - utter_goodbye
    - export
* intent_thanks
    - utter_thanks
## Generated Story -6184663595171551586
    - slot{"actiontype": null}
* intent_bye
    - utter_goodbye
    - export
* intent_thanks
    - utter_thanks
## Generated Story -4163684913875410302
* intent_bye
    - utter_goodbye
    - export
* intent_user_issue{"username": "8745662"}
    - slot{"username": "8745662"}
    - slot{"username": "8745662"}
    - utter_ask_actiontype
## Generated Story -8048466428448587513
    - slot{"actiontype": null}
* intent_bye
    - utter_goodbye
    - export
* intent_greet
    - utter_greet
## Generated Story 6271923021826443557
* intent_bye
    - utter_goodbye
    - export
* intent_user_issue{"actiontype": "activate"}
    - slot{"actiontype": "activate"}
    - slot{"actiontype": "activate"}
    - utter_ask_username
## Generated Story -4163684913875410302
* intent_bye
    - utter_goodbye
    - export
* intent_user_issue{"username": "8745662"}
    - slot{"username": "8745662"}
    - slot{"username": "8745662"}
    - utter_ask_actiontype
## Generated Story -6872664423934330085
* intent_affirm
    - utter_on_it
    - action_on_user
    - slot{"username": null}
    - slot{"actiontype": null}
* intent_thanks
    - utter_thanks
* intent_bye
    - utter_goodbye
    - export
## Generated Story -218229452344574352
    - utter_on_it
    - utter_ask_confirm
* intent_affirm
    - utter_on_it
    - action_on_user
    - slot{"username": null}
    - slot{"actiontype": null}
* intent_bye
    - utter_goodbye
    - export
## Generated Story -6872664423934330085
* intent_affirm
    - utter_on_it
    - action_on_user
    - slot{"username": null}
    - slot{"actiontype": null}
* intent_thanks
    - utter_thanks
* intent_bye
    - utter_goodbye
    - export
## Generated Story -218229452344574352
    - utter_on_it
    - utter_ask_confirm
* intent_affirm
    - utter_on_it
    - action_on_user
    - slot{"username": null}
    - slot{"actiontype": null}
* intent_bye
    - utter_goodbye
    - export
## Generated Story -6872664423934330085
* intent_affirm
    - utter_on_it
    - action_on_user
    - slot{"username": null}
    - slot{"actiontype": null}
* intent_thanks
    - utter_thanks
* intent_bye
    - utter_goodbye
    - export
## Generated Story -218229452344574352
    - utter_on_it
    - utter_ask_confirm
* intent_affirm
    - utter_on_it
    - action_on_user
    - slot{"username": null}
    - slot{"actiontype": null}
* intent_bye
    - utter_goodbye
    - export
## Generated Story -6872664423934330085
* intent_affirm
    - utter_on_it
    - action_on_user
    - slot{"username": null}
    - slot{"actiontype": null}
* intent_thanks
    - utter_thanks
* intent_bye
    - utter_goodbye
    - export
## Generated Story -218229452344574352
    - utter_on_it
    - utter_ask_confirm
* intent_affirm
    - utter_on_it
    - action_on_user
    - slot{"username": null}
    - slot{"actiontype": null}
* intent_bye
    - utter_goodbye
    - export
## Generated Story -6872664423934330085
* intent_affirm
    - utter_on_it
    - action_on_user
    - slot{"username": null}
    - slot{"actiontype": null}
* intent_thanks
    - utter_thanks
* intent_bye
    - utter_goodbye
    - export
## Generated Story -218229452344574352
    - utter_on_it
    - utter_ask_confirm
* intent_affirm
    - utter_on_it
    - action_on_user
    - slot{"username": null}
    - slot{"actiontype": null}
* intent_bye
    - utter_goodbye
    - export
## Generated Story -2820098364009314022
* intent_thanks
    - utter_thanks
* intent_bye
    - utter_goodbye
    - export
## Generated Story 6527953472254908673
    - slot{"username": null}
    - slot{"actiontype": null}
* intent_bye
    - utter_goodbye
    - export
## Generated Story -5726746295095293462
* intent_bye
    - utter_goodbye
    - export
## Generated Story -5726746295095293462
* intent_bye
    - utter_goodbye
    - export
## Generated Story -2820098364009314022
* intent_thanks
    - utter_thanks
* intent_bye
    - utter_goodbye
    - export
## Generated Story 6527953472254908673
    - slot{"username": null}
    - slot{"actiontype": null}
* intent_bye
    - utter_goodbye
    - export
## Generated Story -5726746295095293462
* intent_bye
    - utter_goodbye
    - export
## Generated Story -2820098364009314022
* intent_thanks
    - utter_thanks
* intent_bye
    - utter_goodbye
    - export
## Generated Story 6527953472254908673
    - slot{"username": null}
    - slot{"actiontype": null}
* intent_bye
    - utter_goodbye
    - export
## Generated Story -5726746295095293462
* intent_bye
    - utter_goodbye
    - export
## Generated Story -5726746295095293462
* intent_bye
    - utter_goodbye
    - export
## Generated Story -2820098364009314022
* intent_thanks
    - utter_thanks
* intent_bye
    - utter_goodbye
    - export
## Generated Story 6527953472254908673
    - slot{"username": null}
    - slot{"actiontype": null}
* intent_bye
    - utter_goodbye
    - export
## Generated Story -5726746295095293462
* intent_bye
    - utter_goodbye
    - export
## Generated Story -5726746295095293462
* intent_bye
    - utter_goodbye
    - export
## Generated Story 4040123941260574369
* intent_greet
    - utter_greet
* intent_user_issue{"actiontype": "activate"}
    - slot{"actiontype": "activate"}
    - utter_ask_username
* intent_greet{"username": "988382"}
    - slot{"username": "988382"}
    - utter_on_it
    - utter_ask_confirm
* intent_affirm
    - utter_on_it
    - action_on_user
    - slot{"username": null}
    - slot{"actiontype": null}
* 
* intent_thanks
    - utter_thanks
* intent_user_issue{"username": "20233030", "actiontype": "deactivate"}
    - slot{"actiontype": "deactivate"}
    - slot{"username": "20233030"}
    - utter_on_it
    - utter_ask_confirm
* intent_affirm
    - utter_on_it
    - action_on_user
    - slot{"username": null}
    - slot{"actiontype": null}
* intent_thanks
    - utter_thanks
    - export
## Generated Story -8349929324974968619
    - utter_on_it
    - action_on_user
    - slot{"username": null}
    - slot{"actiontype": null}
* intent_bye
    - utter_goodbye
    - export
## Generated Story -4923680183233286810
    - slot{"actiontype": null}
* intent_thanks
    - utter_thanks
* intent_bye
    - utter_goodbye
    - export
## Generated Story 1997892567769085246
* intent_thanks
    - utter_thanks
* intent_bye
    - utter_goodbye
    - export
## Generated Story 1622750737903272372
    - slot{"username": null}
    - slot{"actiontype": null}
* intent_bye
    - utter_goodbye
    - export
## Generated Story -8349929324974968619
    - utter_on_it
    - action_on_user
    - slot{"username": null}
    - slot{"actiontype": null}
* intent_bye
    - utter_goodbye
    - export
## Generated Story -4923680183233286810
    - slot{"actiontype": null}
* intent_thanks
    - utter_thanks
* intent_bye
    - utter_goodbye
    - export
## Generated Story -1585192904650955881
    - export
* intent_thanks
    - utter_thanks
## Generated Story 1997892567769085246
* intent_thanks
    - utter_thanks
* intent_bye
    - utter_goodbye
    - export
## Generated Story 1622750737903272372
    - slot{"username": null}
    - slot{"actiontype": null}
* intent_bye
    - utter_goodbye
    - export
## Generated Story 5977114281169058592
    - export
* intent_greet
    - utter_greet
## Generated Story -8349929324974968619
    - utter_on_it
    - action_on_user
    - slot{"username": null}
    - slot{"actiontype": null}
* intent_bye
    - utter_goodbye
    - export
## Generated Story -4923680183233286810
    - slot{"actiontype": null}
* intent_thanks
    - utter_thanks
* intent_bye
    - utter_goodbye
    - export
## Generated Story -8349929324974968619
    - utter_on_it
    - action_on_user
    - slot{"username": null}
    - slot{"actiontype": null}
* intent_bye
    - utter_goodbye
    - export
## Generated Story -4923680183233286810
    - slot{"actiontype": null}
* intent_thanks
    - utter_thanks
* intent_bye
    - utter_goodbye
    - export
## Generated Story 1622750737903272372
    - slot{"username": null}
    - slot{"actiontype": null}
* intent_bye
    - utter_goodbye
    - export
## Generated Story -8349929324974968619
    - utter_on_it
    - action_on_user
    - slot{"username": null}
    - slot{"actiontype": null}
* intent_bye
    - utter_goodbye
    - export
## Generated Story -4923680183233286810
    - slot{"actiontype": null}
* intent_thanks
    - utter_thanks
* intent_bye
    - utter_goodbye
    - export
## Generated Story 1997892567769085246
* intent_thanks
    - utter_thanks
* intent_bye
    - utter_goodbye
    - export
