'''
Created on 16-Apr-2018

@author: kkund
'''
#from django.contrib.postgres.fields import JSONField
#from rest_framework import serializers
#from rest_framework.serializers import ModelSerializer

#class ChatMsg():
    #req_msg = JSONField()
    #res_msg = JSONField()
    
#class ChatMsgSerializer(ModelSerializer):
    
    #class Meta:
     #   model = ChatMsg
     #   fields = ['req_msg','res_msg']
    